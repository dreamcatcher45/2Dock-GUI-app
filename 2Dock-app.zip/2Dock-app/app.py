#!/usr/bin/env python3

import tkinter
import customtkinter
import sys
import os  
import tkinter as tk
customtkinter.set_appearance_mode("System") 
customtkinter.set_default_color_theme("green")  

app = customtkinter.CTk()  
app.title("2Dock")
app.geometry("200x180")
app.resizable(width=False, height=False)

def run():
    os.system('./setup.sh')
def res():
    os.system('./restore.sh') 


button = customtkinter.CTkButton(master=app, text="Setup", command=run)
button.place(relx=0.5, rely=0.3, anchor=tkinter.CENTER)

button = customtkinter.CTkButton(master=app, text="Restore", command=res)
button.place(relx=0.5, rely=0.6, anchor=tkinter.CENTER)

app.mainloop()
